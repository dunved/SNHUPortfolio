import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    private TaskService service;

    @BeforeEach
    public void setUp() {
        service = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("P100", "Snorlax", "Large normal-type Pokémon that blocks paths");
        service.addTask(task);
        assertEquals(task, service.getTask("P100"));
    }

    @Test
    public void testAddDuplicateIdThrowsException() {
        Task task1 = new Task("P200", "Mewtwo", "Psychic-type legendary Pokémon");
        Task task2 = new Task("P200", "Mew", "Psychic-type mythical Pokémon");

        service.addTask(task1);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task2);
        });
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("P300", "Gengar", "Ghost/Poison-type from Lavender Town");
        service.addTask(task);
        service.deleteTask("P300");
        assertNull(service.getTask("P300"));
    }

    @Test
    public void testDeleteNonExistentTaskThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("P404");
        });
    }

    @Test
    public void testUpdateName() {
        Task task = new Task("P500", "Growlithe", "Fire-type loyal Pokémon");
        service.addTask(task);
        service.updateTaskName("P500", "Arcanine");
        assertEquals("Arcanine", service.getTask("P500").getName());
    }

    @Test
    public void testUpdateDescription() {
        Task task = new Task("P600", "Lapras", "Ice/Water ferry Pokémon");
        service.addTask(task);
        service.updateTaskDescription("P600", "Gentle water Pokémon that carries humans");
        assertEquals("Gentle water Pokémon that carries humans", service.getTask("P600").getDescription());
    }

    @Test
    public void testUpdateNonExistentTaskThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskName("P999", "MissingNo");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskDescription("P999", "Glitch Pokémon");
        });
    }
}