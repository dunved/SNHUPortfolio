import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import java.util.Date;
import java.util.Calendar;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Test class for AppointmentService
 */
public class AppointmentServiceTest {
    
    private AppointmentService service;
    private Date futureDate;
    private Date anotherFutureDate;
    
    @BeforeEach
    void setUp() {
        service = new AppointmentService();
        
        Calendar calendar = Calendar.getInstance();
        // Set future date (tomorrow)
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        futureDate = calendar.getTime();
        
        // Set another future date (day after tomorrow)
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        anotherFutureDate = calendar.getTime();
    }
    
    @Test
    @DisplayName("Test adding appointment with Ash's Pikachu")
    void testAddAppointment() {
        Appointment pikachuAppointment = new Appointment("PIKA025", futureDate, "Thunderbolt training with Pikachu");
        service.addAppointment(pikachuAppointment);
        
        assertTrue(service.appointmentExists("PIKA025"));
        assertEquals(1, service.getAppointmentCount());
    }
    
    @Test
    @DisplayName("Test adding appointment with parameters - Charmander evolution")
    void testAddAppointmentWithParameters() {
        service.addAppointment("CHAR004", futureDate, "Charmander evolution to Charmeleon");
        
        assertTrue(service.appointmentExists("CHAR004"));
        Appointment retrieved = service.getAppointment("CHAR004");
        assertNotNull(retrieved);
        assertEquals("Charmander evolution to Charmeleon", retrieved.getDescription());
    }
    
    @Test
    @DisplayName("Test adding multiple Pokémon appointments")
    void testAddMultipleAppointments() {
        service.addAppointment("BULB001", futureDate, "Bulbasaur's Vine Whip practice");
        service.addAppointment("SQUR007", futureDate, "Squirtle's Water Gun training");
        service.addAppointment("PIDGE016", anotherFutureDate, "Pidgeotto flying lessons");
        
        assertEquals(3, service.getAppointmentCount());
        assertTrue(service.appointmentExists("BULB001"));
        assertTrue(service.appointmentExists("SQUR007"));
        assertTrue(service.appointmentExists("PIDGE016"));
    }
    
    @Test
    @DisplayName("Test adding duplicate Pokémon ID throws exception - Two Mewtwos")
    void testAddDuplicateAppointmentId() {
        service.addAppointment("MEW150", futureDate, "First Mewtwo encounter");
        
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment("MEW150", anotherFutureDate, "Second Mewtwo encounter");
        });
        
        assertTrue(exception.getMessage().contains("already exists"));
        assertEquals(1, service.getAppointmentCount());
    }
    
    @Test
    @DisplayName("Test adding null appointment throws exception")
    void testAddNullAppointment() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(null);
        });
        
        assertEquals(0, service.getAppointmentCount());
    }
    
    @Test
    @DisplayName("Test deleting Team Rocket appointment")
    void testDeleteAppointment() {
        service.addAppointment("ROCK123", futureDate, "Stop Team Rocket at Mt. Moon");
        assertEquals(1, service.getAppointmentCount());
        
        service.deleteAppointment("ROCK123");
        
        assertFalse(service.appointmentExists("ROCK123"));
        assertEquals(0, service.getAppointmentCount());
    }
    
    @Test
    @DisplayName("Test deleting non-existent Pokémon throws exception - Missing Mew")
    void testDeleteNonExistentAppointment() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("MEW151");
        });
        
        assertTrue(exception.getMessage().contains("not found"));
    }
    
    @Test
    @DisplayName("Test deleting with null ID throws exception")
    void testDeleteNullAppointmentId() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment(null);
        });
    }
    
    @Test
    @DisplayName("Test getting Gym Leader appointments")
    void testGetAppointment() {
        service.addAppointment("GYM001", futureDate, "Battle Brock at Pewter City");
        service.addAppointment("GYM002", futureDate, "Battle Misty at Cerulean City");
        
        Appointment brock = service.getAppointment("GYM001");
        Appointment misty = service.getAppointment("GYM002");
        
        assertNotNull(brock);
        assertNotNull(misty);
        assertEquals("Battle Brock at Pewter City", brock.getDescription());
        assertEquals("Battle Misty at Cerulean City", misty.getDescription());
    }
    
    @Test
    @DisplayName("Test getting non-existent legendary Pokémon appointment")
    void testGetNonExistentAppointment() {
        Appointment result = service.getAppointment("ARTI144");
        assertNull(result);
    }
    
    @Test
    @DisplayName("Test getting appointment with null ID")
    void testGetAppointmentWithNullId() {
        Appointment result = service.getAppointment(null);
        assertNull(result);
    }
    
    @Test
    @DisplayName("Test appointment exists check - Pokédex entries")
    void testAppointmentExists() {
        service.addAppointment("DEX001", futureDate, "Register Bulbasaur in Pokédex");
        
        assertTrue(service.appointmentExists("DEX001"));
        assertFalse(service.appointmentExists("DEX150"));
        assertFalse(service.appointmentExists(null));
    }
    
    @Test
    @DisplayName("Test clearing all Pokémon Center appointments")
    void testClearAllAppointments() {
        service.addAppointment("HEAL001", futureDate, "Heal Pikachu at Pokémon Center");
        service.addAppointment("HEAL002", futureDate, "Heal Charizard at Pokémon Center");
        service.addAppointment("HEAL003", futureDate, "Heal Blastoise at Pokémon Center");
        
        assertEquals(3, service.getAppointmentCount());
        
        service.clearAllAppointments();
        
        assertEquals(0, service.getAppointmentCount());
        assertFalse(service.appointmentExists("HEAL001"));
        assertFalse(service.appointmentExists("HEAL002"));
        assertFalse(service.appointmentExists("HEAL003"));
    }
    
    @Test
    @DisplayName("Test complex scenario - Pokémon League Championship")
    void testComplexScenario() {
        // Add Elite Four appointments
        service.addAppointment("ELITE001", futureDate, "Battle Lorelei - Ice type");
        service.addAppointment("ELITE002", futureDate, "Battle Bruno - Fighting type");
        service.addAppointment("ELITE003", futureDate, "Battle Agatha - Ghost type");
        service.addAppointment("ELITE004", futureDate, "Battle Lance - Dragon type");
        
        assertEquals(4, service.getAppointmentCount());
        
        // Complete Lorelei battle
        service.deleteAppointment("ELITE001");
        assertEquals(3, service.getAppointmentCount());
        
        // Add Champion battle
        service.addAppointment("CHAMP001", anotherFutureDate, "Battle Gary Oak for Championship");
        assertEquals(4, service.getAppointmentCount());
        
        // Verify specific appointments
        assertFalse(service.appointmentExists("ELITE001")); // Deleted
        assertTrue(service.appointmentExists("ELITE002"));  // Still exists
        assertTrue(service.appointmentExists("CHAMP001"));  // Newly added
        
        // Get champion appointment details
        Appointment championship = service.getAppointment("CHAMP001");
        assertEquals("Battle Gary Oak for Championship", championship.getDescription());
    }
    
    @Test
    @DisplayName("Test appointment isolation - Each Pokémon has separate appointment")
    void testAppointmentIsolation() {
        // Add appointment for different Pokémon
        service.addAppointment("PIKA025", futureDate, "Pikachu's Thunder training");
        service.addAppointment("CHAR006", futureDate, "Charizard's Flamethrower practice");
        
        // Delete one appointment
        service.deleteAppointment("PIKA025");
        
        // Other appointment should remain unaffected
        assertTrue(service.appointmentExists("CHAR006"));
        assertFalse(service.appointmentExists("PIKA025"));
        
        Appointment charizard = service.getAppointment("CHAR006");
        assertEquals("Charizard's Flamethrower practice", charizard.getDescription());
    }
}