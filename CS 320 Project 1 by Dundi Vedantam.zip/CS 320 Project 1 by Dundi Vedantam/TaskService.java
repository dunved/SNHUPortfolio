import java.util.HashMap;

public class TaskService {
    private HashMap<String, Task> taskMap;

    public TaskService() {
        taskMap = new HashMap<>();
    }

    // Add a new task with a unique ID
    public void addTask(Task task) {
        if (task == null || taskMap.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task already exists or is null");
        }
        taskMap.put(task.getTaskId(), task);
    }

    // Delete a task by ID
    public void deleteTask(String taskId) {
        if (!taskMap.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID does not exist");
        }
        taskMap.remove(taskId);
    }
    
    public Task getTask(String taskId) {
        return taskMap.get(taskId);
    }

    // Update the name of a task by ID
    public void updateTaskName(String taskId, String newName) {
        Task task = taskMap.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID does not exist");
        }
        task.setName(newName);
    }

    // Update the description of a task by ID
    public void updateTaskDescription(String taskId, String newDescription) {
        Task task = taskMap.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID does not exist");
        }
        task.setDescription(newDescription);
    }