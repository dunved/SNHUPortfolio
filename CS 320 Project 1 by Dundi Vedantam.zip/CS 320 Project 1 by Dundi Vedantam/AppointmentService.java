import java.util.HashMap;
import java.util.Map;
import java.util.Date;

/**
 * The AppointmentService class manages appointments in memory.
 * It provides functionality to add and delete appointments.
 */
public class AppointmentService {
    
    // In-memory storage for appointments
    private final Map<String, Appointment> appointments;
    
    /**
     * Constructor initializes the appointment storage
     */
    public AppointmentService() {
        this.appointments = new HashMap<>();
    }
    
    /**
     * Adds a new appointment to the service
     * @param appointment The appointment to add
     * @throws IllegalArgumentException if appointment is null or ID already exists
     */
    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment cannot be null");
        }
        
        String appointmentId = appointment.getAppointmentId();
        
        // Check if appointment with this ID already exists
        if (appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment with ID " + appointmentId + " already exists");
        }
        
        appointments.put(appointmentId, appointment);
    }
    
    /**
     * Adds a new appointment by creating it with the provided parameters
     * @param appointmentId The unique appointment ID
     * @param appointmentDate The appointment date
     * @param description The appointment description
     * @throws IllegalArgumentException if parameters are invalid or ID already exists
     */
    public void addAppointment(String appointmentId, Date appointmentDate, String description) {
        // Create new appointment (validation happens in Appointment constructor)
        Appointment appointment = new Appointment(appointmentId, appointmentDate, description);
        
        // Add the appointment
        addAppointment(appointment);
    }
    
    /**
     * Deletes an appointment by its ID
     * @param appointmentId The ID of the appointment to delete
     * @throws IllegalArgumentException if appointmentId is null or appointment not found
     */
    public void deleteAppointment(String appointmentId) {
        if (appointmentId == null) {
            throw new IllegalArgumentException("Appointment ID cannot be null");
        }
        
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment with ID " + appointmentId + " not found");
        }
        
        appointments.remove(appointmentId);
    }
    
    /**
     * Retrieves an appointment by its ID
     * @param appointmentId The ID of the appointment to retrieve
     * @return The appointment if found, null otherwise
     */
    public Appointment getAppointment(String appointmentId) {
        if (appointmentId == null) {
            return null;
        }
        return appointments.get(appointmentId);
    }
    
    /**
     * Checks if an appointment exists with the given ID
     * @param appointmentId The ID to check
     * @return true if appointment exists, false otherwise
     */
    public boolean appointmentExists(String appointmentId) {
        if (appointmentId == null) {
            return false;
        }
        return appointments.containsKey(appointmentId);
    }
    
    /**
     * Gets the total number of appointments
     * @return The number of appointments in the service
     */
    public int getAppointmentCount() {
        return appointments.size();
    }
    
    /**
     * Clears all appointments from the service
     */
    public void clearAllAppointments() {
        appointments.clear();
    }
}