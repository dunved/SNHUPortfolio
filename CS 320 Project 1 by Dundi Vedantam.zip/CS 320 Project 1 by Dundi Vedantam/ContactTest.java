import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testContactCreation() {
        Contact contact = new Contact("025", "Pikachu", "Electric", "1234567890", "Viridian Forest");

        assertEquals("025", contact.getContactId());
        assertEquals("Pikachu", contact.getFirstName());
        assertEquals("Electric", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("Viridian Forest", contact.getAddress());
    }

    @Test
    public void testSetters() {
        Contact contact = new Contact("039", "Jigglypuff", "Balloon", "0987654321", "Mt. Moon");

        contact.setFirstName("Wigglytuff");
        contact.setLastName("Fairy");
        contact.setPhone("5555555555");
        contact.setAddress("Lavender Town");

        assertEquals("Wigglytuff", contact.getFirstName());
        assertEquals("Fairy", contact.getLastName());
        assertEquals("5555555555", contact.getPhone());
        assertEquals("Lavender Town", contact.getAddress());
    }
}