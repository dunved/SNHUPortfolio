import java.util.Date;

/**
 * The Appointment class represents an appointment with a unique ID,
 * date, and description. All fields are immutable after creation.
 */
public class Appointment {
    
    // Constants for validation
    private static final int MAX_ID_LENGTH = 10;
    private static final int MAX_DESCRIPTION_LENGTH = 50;
    
    // Immutable fields
    private final String appointmentId;
    private final Date appointmentDate;
    private final String description;
    
    /**
     * Constructor for Appointment
     * @param appointmentId Unique ID (max 10 characters, cannot be null)
     * @param appointmentDate Date of appointment (cannot be null or in the past)
     * @param description Description of appointment (max 50 characters, cannot be null)
     * @throws IllegalArgumentException if any parameter is invalid
     */
    public Appointment(String appointmentId, Date appointmentDate, String description) {
        // Validate appointment ID
        if (appointmentId == null || appointmentId.isEmpty()) {
            throw new IllegalArgumentException("Appointment ID cannot be null or empty");
        }
        if (appointmentId.length() > MAX_ID_LENGTH) {
            throw new IllegalArgumentException("Appointment ID cannot exceed " + MAX_ID_LENGTH + " characters");
        }
        
        // Validate appointment date
        if (appointmentDate == null) {
            throw new IllegalArgumentException("Appointment date cannot be null");
        }
        if (appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date cannot be in the past");
        }
        
        // Validate description
        if (description == null) {
            throw new IllegalArgumentException("Description cannot be null");
        }
        if (description.length() > MAX_DESCRIPTION_LENGTH) {
            throw new IllegalArgumentException("Description cannot exceed " + MAX_DESCRIPTION_LENGTH + " characters");
        }
        
        // Set immutable fields
        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }
    
    /**
     * Gets the appointment ID
     * @return the appointment ID
     */
    public String getAppointmentId() {
        return appointmentId;
    }
    
    /**
     * Gets the appointment date
     * @return the appointment date
     */
    public Date getAppointmentDate() {
        return appointmentDate;
    }
    
    /**
     * Gets the appointment description
     * @return the appointment description
     */
    public String getDescription() {
        return description;
    }
    
    /**
     * Returns a string representation of the appointment
     * @return string representation
     */
    @Override
    public String toString() {
        return "Appointment{" +
                "appointmentId='" + appointmentId + '\'' +
                ", appointmentDate=" + appointmentDate +
                ", description='" + description + '\'' +
                '}';
    }
}