import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;

public class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }

    @Test
    public void testAddContact() {
        Contact contact = new Contact("001", "Bulbasaur", "Seed", "1112223333", "Pallet Town");
        service.addContact(contact);
        List<Contact> contacts = service.getAllContacts();
        assertEquals(1, contacts.size());
        assertEquals("Bulbasaur", contacts.get(0).getFirstName());
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("004", "Charmander", "Flame", "4445556666", "Cinnabar Island");
        service.addContact(contact);
        assertTrue(service.deleteContact("004"));
        assertFalse(service.deleteContact("999")); 
    }

    @Test
    public void testUpdateContact() {
        Contact contact = new Contact("007", "Squirtle", "TinyTurtle", "7778889999", "Cerulean City");
        service.addContact(contact);

        assertTrue(service.updateContact("007", "Wartortle", "Turtle", "9998887777", "Vermilion City"));
        Contact updated = service.getAllContacts().get(0);

        assertEquals("Wartortle", updated.getFirstName());
        assertEquals("Turtle", updated.getLastName());
        assertEquals("9998887777", updated.getPhone());
        assertEquals("Vermilion City", updated.getAddress());
    }

    @Test
    public void testUpdateNonExistentContact() {
        assertFalse(service.updateContact("999", "Eevee", "Evolution", "1234567890", "Celadon City"));
    }

    @Test
    public void testDeleteNonExistentContact() {
        assertFalse(service.deleteContact("999"));
    }