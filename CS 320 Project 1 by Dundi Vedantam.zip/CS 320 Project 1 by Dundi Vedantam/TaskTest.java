import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testValidTaskCreation() {
        Task task = new Task("P001", "Pikachu", "Electric-type mascot of the franchise");
        assertEquals("P001", task.getTaskId());
        assertEquals("Pikachu", task.getName());
        assertEquals("Electric-type mascot of the franchise", task.getDescription());
    }

    @Test
    public void testTaskIdConstraints() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Charmander", "Fire-type starter Pokémon");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Bulbasaur", "Grass/Poison-type starter Pokémon");
        });
    }

    @Test
    public void testNameConstraints() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("P002", null, "Fire-type Pokémon");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Task("P002", "ThisIsAVeryLongPokemonNameExceedingLimit", "Too long name");
        });
    }

    @Test
    public void testDescriptionConstraints() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("P003", "Squirtle", null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Task("P003", "Squirtle", "This description is way too long to be accepted. It clearly exceeds fifty characters.");
        });
    }

    @Test
    public void testSetName() {
        Task task = new Task("P004", "Eevee", "Normal-type evolution base");
        task.setName("Vaporeon");
        assertEquals("Vaporeon", task.getName());
    }

    @Test
    public void testSetDescription() {
        Task task = new Task("P005", "Meowth", "Team Rocket's talking cat");
        task.setDescription("Normal-type Pokémon, often with Pay Day");
        assertEquals("Normal-type Pokémon, often with Pay Day", task.getDescription());
    }
}