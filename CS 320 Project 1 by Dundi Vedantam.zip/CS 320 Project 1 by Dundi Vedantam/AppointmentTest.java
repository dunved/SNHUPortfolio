import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import java.util.Date;
import java.util.Calendar;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Test class for Appointment
 */
public class AppointmentTest {
    
    private Date futureDate;
    private Date pastDate;
    
    @BeforeEach
    void setUp() {
        Calendar calendar = Calendar.getInstance();
        
        // Set future date (tomorrow)
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        futureDate = calendar.getTime();
        
        // Set past date (yesterday)
        calendar.add(Calendar.DAY_OF_MONTH, -2);
        pastDate = calendar.getTime();
    }
    
    @Test
    @DisplayName("Test creating valid appointment with Pikachu")
    void testValidAppointmentCreation() {
        Appointment appointment = new Appointment("PIKA001", futureDate, "Battle training with Pikachu");
        
        assertNotNull(appointment);
        assertEquals("PIKA001", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Battle training with Pikachu", appointment.getDescription());
    }
    
    @Test
    @DisplayName("Test appointment with max length ID - Charizard")
    void testMaxLengthAppointmentId() {
        String maxLengthId = "CHARIZARD1"; // Exactly 10 characters
        Appointment appointment = new Appointment(maxLengthId, futureDate, "Fire type training session");
        
        assertEquals(maxLengthId, appointment.getAppointmentId());
    }
    
    @Test
    @DisplayName("Test appointment with max length description - Gym Battle")
    void testMaxLengthDescription() {
        String maxDescription = "Gym battle at Cerulean City with Misty - Water type"; // 50 characters
        Appointment appointment = new Appointment("GYM002", futureDate, maxDescription);
        
        assertEquals(maxDescription, appointment.getDescription());
    }
    
    @Test
    @DisplayName("Test null appointment ID throws exception")
    void testNullAppointmentIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Pokémon Center checkup");
        });
    }
    
    @Test
    @DisplayName("Test empty appointment ID throws exception")
    void testEmptyAppointmentIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("", futureDate, "Professor Oak meeting");
        });
    }
    
    @Test
    @DisplayName("Test appointment ID too long - Legendary Pokémon")
    void testAppointmentIdTooLong() {
        String tooLongId = "LEGENDARY123"; // 12 characters (exceeds 10)
        
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(tooLongId, futureDate, "Catch Mewtwo");
        });
        
        assertTrue(exception.getMessage().contains("10 characters"));
    }
    
    @Test
    @DisplayName("Test null appointment date throws exception")
    void testNullAppointmentDateThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("BULBA001", null, "Bulbasaur evolution ceremony");
        });
    }
    
    @Test
    @DisplayName("Test past appointment date throws exception - Missed Safari Zone")
    void testPastAppointmentDateThrowsException() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("SAFARI001", pastDate, "Safari Zone expedition");
        });
        
        assertTrue(exception.getMessage().contains("past"));
    }
    
    @Test
    @DisplayName("Test null description throws exception")
    void testNullDescriptionThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("SQUIR001", futureDate, null);
        });
    }
    
    @Test
    @DisplayName("Test description too long - Team Rocket")
    void testDescriptionTooLong() {
        String tooLongDescription = "Stop Team Rocket from stealing Pokémon at the Viridian City Pokémon Center tonight"; // >50 chars
        
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("ROCKET001", futureDate, tooLongDescription);
        });
        
        assertTrue(exception.getMessage().contains("50 characters"));
    }
    
    @Test
    @DisplayName("Test appointment immutability - Cannot change Eevee evolution")
    void testAppointmentImmutability() {
        Date originalDate = new Date(futureDate.getTime());
        Appointment appointment = new Appointment("EEVEE001", futureDate, "Choose Eevee evolution");
        
        // Modify the original date
        futureDate.setTime(futureDate.getTime() + 86400000L); // Add one day
        
        // Appointment date should remain unchanged
        assertEquals(originalDate, appointment.getAppointmentDate());
    }
    
    @Test
    @DisplayName("Test multiple valid appointments - Elite Four")
    void testMultipleValidAppointments() {
        Appointment lorelei = new Appointment("ELITE001", futureDate, "Battle Lorelei - Ice type");
        Appointment bruno = new Appointment("ELITE002", futureDate, "Battle Bruno - Fighting type");
        Appointment agatha = new Appointment("ELITE003", futureDate, "Battle Agatha - Ghost type");
        Appointment lance = new Appointment("ELITE004", futureDate, "Battle Lance - Dragon type");
        
        assertNotNull(lorelei);
        assertNotNull(bruno);
        assertNotNull(agatha);
        assertNotNull(lance);
        
        // Verify each has unique ID
        assertNotEquals(lorelei.getAppointmentId(), bruno.getAppointmentId());
        assertNotEquals(bruno.getAppointmentId(), agatha.getAppointmentId());
        assertNotEquals(agatha.getAppointmentId(), lance.getAppointmentId());
    }
    
    @Test
    @DisplayName("Test toString method - Snorlax")
    void testToStringMethod() {
        Appointment appointment = new Appointment("SNOR001", futureDate, "Wake up Snorlax on Route 12");
        String result = appointment.toString();
        
        assertTrue(result.contains("SNOR001"));
        assertTrue(result.contains("Wake up Snorlax on Route 12"));
        assertNotNull(result);
    }
}