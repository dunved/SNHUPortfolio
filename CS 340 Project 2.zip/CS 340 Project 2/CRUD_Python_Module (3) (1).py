"""
CRUD_Python_Module.py
CS 340 – Module Four Milestone
Create/Read access for the AAC 'animals' collection using PyMongo.
"""

from typing import Any, Dict, List, Optional
from pymongo import MongoClient, errors


class MongoCRUD:
    """
    Minimal, reusable CRUD class for MongoDB.
    Milestone 4 focuses on Create and Read operations.
    """

    def __init__(
        self,
        username: str,
        password: str,
        host: str = "localhost",
        port: int = 27017,
        db_name: str = "admin",
        collection_name: str = "animals",
        auth_source: str = "admin",     
        **client_kwargs: Any,
    ) -> None:
        try:
            uri = f"mongodb://{username}:{password}@{host}:{port}/?authSource={auth_source}"
            self._client = MongoClient(uri, serverSelectionTimeoutMS=5000, **client_kwargs)
            self._client.admin.command("ping")
            self._db = self._client[db_name]
            self._collection = self._db[collection_name]
        except errors.PyMongoError as e:
            raise RuntimeError(f"Could not connect to MongoDB: {e}")

    # ---------- C: CREATE ----------
    def create(self, data: Dict[str, Any]) -> bool:
        if not isinstance(data, dict) or not data:
            return False
        try:
            result = self._collection.insert_one(data)
            return bool(result.acknowledged and result.inserted_id)
        except errors.PyMongoError:
            return False

    # ---------- R: READ ----------
    def read(
        self,
        query: Optional[Dict[str, Any]] = None,
        projection: Optional[Dict[str, int]] = None,
        limit: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        try:
            cursor = self._collection.find(query or {}, projection)
            if limit:
                cursor = cursor.limit(int(limit))
            return list(cursor)
        except errors.PyMongoError:
            return []

    def close(self) -> None:
        try:
            self._client.close()
        except Exception:
            pass
 # ---------- U: UPDATE ----------
    def update(self, query: Dict[str, Any], new_values: Dict[str, Any]) -> int:
        """
        Update documents that match 'query' by setting 'new_values'.
        Return the number of documents modified.
        """
        if not isinstance(query, dict) or not isinstance(new_values, dict) or not new_values:
            return 0
        try:
            result = self._collection.update_many(query, {"$set": new_values})
            return int(result.modified_count)
        except errors.PyMongoError:
            return 0

# ---------- D: DELETE ----------
    def delete(self, query: Dict[str, Any]) -> int:
        if not isinstance(query, dict) or not query:
            return 0
        try:
            result = self._collection.delete_many(query)
            return int(result.deleted_count)
        except errors.PyMongoError:
            return 0